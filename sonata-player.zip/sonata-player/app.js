/* Sonata — desktop music player prototype */
(() => {
  'use strict';

  const $ = (sel) => document.querySelector(sel);
  const audio = $('#audio');

  const DEMO_TRACKS = [
    {
      id: 't1', title: 'Утренний свет', artist: 'Aurora Fields', album: 'Morning Light',
      src: 'assets/audio/morning-light.wav', cover: 'assets/covers/morning-light.svg',
      duration: 46.8, quality: 'WAV · 22 кГц', gradient: 'linear-gradient(115deg, rgba(58,42,105,.95), rgba(24,28,45,.95) 55%, rgba(30,48,46,.95))',
    },
    {
      id: 't2', title: 'Неоновый дождь', artist: 'Luna Wave', album: 'Neon Rain',
      src: 'assets/audio/neon-rain.wav', cover: 'assets/covers/neon-rain.svg',
      duration: 40.9, quality: 'WAV · 22 кГц', gradient: 'linear-gradient(115deg, rgba(43,29,107,.95), rgba(31,35,71,.95) 55%, rgba(15,70,83,.95))',
    },
    {
      id: 't3', title: 'Полночный город', artist: 'Night Atlas', album: 'Midnight City',
      src: 'assets/audio/midnight-city.wav', cover: 'assets/covers/midnight-city.svg',
      duration: 53.3, quality: 'WAV · 22 кГц', gradient: 'linear-gradient(115deg, rgba(19,29,74,.95), rgba(33,42,80,.95) 55%, rgba(75,48,85,.95))',
    },
    {
      id: 't4', title: 'Тёплый ветер', artist: 'Solar Drift', album: 'Warm Wind',
      src: 'assets/audio/warm-wind.wav', cover: 'assets/covers/warm-wind.svg',
      duration: 36.9, quality: 'WAV · 22 кГц', gradient: 'linear-gradient(115deg, rgba(13,80,86,.95), rgba(23,116,101,.95) 55%, rgba(87,119,63,.95))',
    },
  ];

  const DEFAULT_PLAYLISTS = [
    { id: 'p1', name: 'Спокойный фокус', color: '#8f7bff', ids: ['t1', 't3'] },
    { id: 'p2', name: 'Вечерний вайб', color: '#64ddc0', ids: ['t2', 't4'] },
  ];

  const state = {
    tracks: [...DEMO_TRACKS],
    queue: [...DEMO_TRACKS],
    currentId: DEMO_TRACKS[0].id,
    playing: false,
    shuffle: false,
    repeat: 0, // 0 — выкл, 1 — весь список, 2 — один трек
    view: 'all',
    query: '',
    favorites: new Set(),
    playlists: [...DEFAULT_PLAYLISTS],
    volume: 72,
    muted: false,
  };

  /* ---------- helpers ---------- */
  const fmt = (s) => {
    if (!isFinite(s) || s < 0) s = 0;
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60).toString().padStart(2, '0');
    return `${m}:${sec}`;
  };
  const trackById = (id) => state.tracks.find((t) => t.id === id);
  const current = () => trackById(state.currentId) || state.tracks[0];
  const currentIndex = () => state.queue.findIndex((t) => t.id === state.currentId);

  function loadStorage() {
    try {
      const fav = JSON.parse(localStorage.getItem('sonata:favorites') || '[]');
      if (Array.isArray(fav)) state.favorites = new Set(fav);
      const pls = JSON.parse(localStorage.getItem('sonata:playlists') || 'null');
      if (Array.isArray(pls)) state.playlists = pls;
    } catch (_) { /* ignore corrupt storage */ }
  }
  function saveStorage() {
    localStorage.setItem('sonata:favorites', JSON.stringify([...state.favorites]));
    localStorage.setItem('sonata:playlists', JSON.stringify(state.playlists));
  }

  let toastTimer;
  function toast(message) {
    const el = $('#toast');
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
  }

  function generatedCover(seed) {
    let h = 0;
    for (const ch of seed) h = (h * 31 + ch.charCodeAt(0)) % 360;
    const hue = h;
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 600"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="hsl(${hue},68%,52%)"/><stop offset="1" stop-color="hsl(${(hue + 65) % 360},60%,26%)"/></linearGradient></defs><rect width="600" height="600" fill="url(#g)"/><circle cx="410" cy="190" r="150" fill="#fff" opacity=".11"/><circle cx="190" cy="430" r="220" fill="#000" opacity=".1"/><path d="M0 400c120-90 210 40 330-30s190-30 270 20v210H0z" fill="#000" opacity=".16"/></svg>`;
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }

  /* ---------- views ---------- */
  function visibleTracks() {
    let list = [...state.tracks];
    if (state.view === 'favorites') list = list.filter((t) => state.favorites.has(t.id));
    else if (state.view === 'recent') list = list.slice().reverse().slice(0, 8);
    else if (state.view.startsWith('playlist:')) {
      const pl = state.playlists.find((p) => p.id === state.view.slice(9));
      list = pl ? pl.ids.map(trackById).filter(Boolean) : [];
    }
    if (state.query) {
      const q = state.query.toLowerCase();
      list = list.filter((t) => `${t.title} ${t.artist} ${t.album}`.toLowerCase().includes(q));
    }
    return list;
  }

  function viewInfo() {
    if (state.view === 'favorites') return { title: 'Любимое', section: 'Любимые треки', sub: 'Треки, которые вы отметили сердечком' };
    if (state.view === 'recent') return { title: 'Недавние', section: 'Недавно добавленные', sub: 'Последние треки в вашей медиатеке' };
    if (state.view.startsWith('playlist:')) {
      const pl = state.playlists.find((p) => p.id === state.view.slice(9));
      return { title: pl ? pl.name : 'Плейлист', section: pl ? pl.name : 'Плейлист', sub: pl ? `${pl.ids.length} треков в плейлисте` : '' };
    }
    return { title: 'Моя музыка', section: 'Все треки', sub: 'Ваша коллекция' };
  }

  function renderPlaylistNav() {
    const wrap = $('#playlistNav');
    document.querySelectorAll('.nav-item[data-view]').forEach((b) => b.classList.toggle('active', b.dataset.view === state.view));
    wrap.innerHTML = state.playlists.map((pl) => {
      const active = state.view === `playlist:${pl.id}` ? ' active' : '';
      return `<button class="nav-item${active}" data-playlist="${pl.id}"><span class="playlist-dot" style="background:${pl.color}"></span><span>${escapeHtml(pl.name)}</span><span class="nav-count">${pl.ids.length}</span></button>`;
    }).join('');
    wrap.querySelectorAll('[data-playlist]').forEach((btn) => {
      btn.addEventListener('click', () => {
        state.view = `playlist:${btn.dataset.playlist}`;
        renderAll();
      });
    });
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function renderTracks() {
    const list = visibleTracks();
    const info = viewInfo();
    $('#viewTitle').textContent = info.title;
    $('#sectionTitle').textContent = info.section;
    $('#sectionSub').textContent = state.query ? `Результаты поиска: «${state.query}»` : info.sub;
    $('#emptyState').hidden = list.length > 0;
    $('#trackList').innerHTML = list.map((t) => {
      const isActive = t.id === state.currentId;
      const liked = state.favorites.has(t.id);
      return `<div class="track-row${isActive ? ' active' : ''}" data-id="${t.id}" title="Нажмите, чтобы воспроизвести · ПКМ — меню">
        <div class="track-index"><span class="num">${list.indexOf(t) + 1}</span><span class="eq${state.playing && isActive ? ' playing' : ''}"><i></i><i></i><i></i><i></i></span></div>
        <div class="track-main"><img class="cover track-cover" src="${t.cover}" alt="" /><div class="track-text"><strong>${escapeHtml(t.title)}</strong><span>${escapeHtml(t.artist)}</span></div></div>
        <div class="track-album">${escapeHtml(t.album)}</div>
        <button class="track-heart${liked ? ' liked' : ''}" data-like="${t.id}" title="${liked ? 'Убрать из любимого' : 'В любимое'}" aria-label="Любимое">
          <svg viewBox="0 0 24 24"><path d="M12 20s-7-4.4-7-9.4A4.1 4.1 0 0 1 12 8a4.1 4.1 0 0 1 7 2.6c0 5-7 9.4-7 9.4Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>
        </button>
        <div class="track-duration">${fmt(t.duration || audioDurationCache[t.id] || 0)}</div>
      </div>`;
    }).join('');

    $('#countAll').textContent = state.tracks.length;
    $('#countFavorites').textContent = state.favorites.size;
    const total = state.tracks.reduce((sum, t) => sum + (t.duration || 0), 0);
    $('#libraryStat').textContent = `${state.tracks.length} трека · ${Math.round(total / 60)} мин`;
  }

  const audioDurationCache = {};

  function renderCurrentTrack() {
    const t = current();
    if (!t) return;
    $('#heroCover img').src = t.cover;
    $('#heroTitle').textContent = t.title;
    $('#heroArtist').textContent = t.artist;
    $('#heroAlbum').textContent = t.album;
    $('#heroQuality').textContent = t.quality || 'Аудиофайл';
    $('#playerCover img').src = t.cover;
    $('#playerTitle').textContent = t.title;
    $('#playerArtist').textContent = t.artist;
    $('#hero').style.background = t.gradient || '';
    document.title = `${t.title} — ${t.artist} · Sonata`;
    const liked = state.favorites.has(t.id);
    ['#heroHeart', '#playerHeart'].forEach((s) => $(s).classList.toggle('liked', liked));
    renderQueue();
  }

  function renderQueue() {
    const idx = currentIndex();
    const upcoming = idx >= 0 ? state.queue.slice(idx) : [];
    $('#queueCount').textContent = `${state.queue.length} треков`;
    $('#queueCurrent').innerHTML = upcoming.length ? queueItemHtml(upcoming[0], true) : '';
    $('#queueNext').innerHTML = upcoming.slice(1).map((t) => queueItemHtml(t, false)).join('');
    $('#queueNextLabel').textContent = `Далее · ${Math.max(0, upcoming.length - 1)}`;
    document.querySelectorAll('.queue-item').forEach((el) => {
      el.addEventListener('click', () => playTrack(el.dataset.id));
    });
  }
  function queueItemHtml(t, isCurrent) {
    return `<div class="queue-item${isCurrent ? ' current' : ''}" data-id="${t.id}">
      <img src="${t.cover}" alt="" /><div class="q-text"><strong>${escapeHtml(t.title)}</strong><span>${escapeHtml(t.artist)}</span></div>
      <span class="q-duration">${fmt(t.duration || audioDurationCache[t.id] || 0)}</span></div>`;
  }

  function renderPlayState() {
    document.body.classList.toggle('playing', state.playing);
    $('#heroPlayLabel').textContent = state.playing ? 'Пауза' : 'Слушать';
    $('#heroPlay').setAttribute('aria-label', state.playing ? 'Пауза' : 'Воспроизвести');
    $('#btnPlay').setAttribute('aria-label', state.playing ? 'Пауза' : 'Воспроизвести');
    $('#vizStatus').textContent = state.playing ? 'в эфире' : 'ожидание';
    $('#btnShuffle').classList.toggle('on', state.shuffle);
    $('#btnRepeat').classList.toggle('on', state.repeat > 0);
    $('#btnRepeat').classList.toggle('repeat-one-on', state.repeat === 2);
    $('#btnRepeat').title = ['Повтор выключен', 'Повтор списка', 'Повтор одного трека'][state.repeat];
  }

  function renderAll() {
    renderPlaylistNav();
    renderTracks();
    renderCurrentTrack();
    renderPlayState();
  }

  /* ---------- playback ---------- */
  function playTrack(id, list) {
    if (list) state.queue = [...list];
    if (!state.queue.some((t) => t.id === id)) state.queue = [...state.tracks];
    state.currentId = id;
    const t = current();
    audio.src = t.src;
    audio.load();
    audio.play().then(() => {}).catch(() => toast('Не удалось воспроизвести файл'));
    renderCurrentTrack();
    renderTracks();
  }

  function togglePlay() {
    if (!audio.src) { playTrack(state.currentId); return; }
    if (audio.paused) {
      audio.play().catch(() => toast('Не удалось воспроизвести файл'));
    } else audio.pause();
  }

  function nextTrack(auto = false) {
    const idx = currentIndex();
    if (state.repeat === 2 && auto) {
      audio.currentTime = 0;
      audio.play().catch(() => {});
      return;
    }
    let next;
    if (state.shuffle && state.queue.length > 1) {
      do { next = Math.floor(Math.random() * state.queue.length); } while (next === idx);
    } else {
      next = idx + 1;
      if (next >= state.queue.length) {
        if (state.repeat === 1 || !auto) next = 0;
        else { audio.pause(); state.playing = false; renderPlayState(); return; }
      }
    }
    playTrack(state.queue[next].id);
  }

  function prevTrack() {
    if (audio.currentTime > 3) { audio.currentTime = 0; return; }
    const idx = currentIndex();
    const prev = idx <= 0 ? state.queue.length - 1 : idx - 1;
    if (state.queue[prev]) playTrack(state.queue[prev].id);
  }

  function toggleLike(id) {
    if (state.favorites.has(id)) { state.favorites.delete(id); toast('Удалено из любимого'); }
    else { state.favorites.add(id); toast('Добавлено в любимое'); }
    saveStorage();
    renderTracks();
    renderCurrentTrack();
  }

  function addFiles(fileList) {
    const files = [...fileList].filter((f) => f.type.startsWith('audio/') || /\.(mp3|wav|flac|ogg|m4a|aac|opus)$/i.test(f.name));
    if (!files.length) { toast('Аудиофайлы не найдены'); return; }
    let added = 0;
    files.forEach((file) => {
      const base = file.name.replace(/\.[^.]+$/, '');
      const parts = base.split(/\s+[-–—]\s+/);
      const t = {
        id: 'local-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7),
        title: parts.length > 1 ? parts.slice(1).join(' - ') : base,
        artist: parts.length > 1 ? parts[0] : 'Локальный файл',
        album: 'Мои файлы',
        src: URL.createObjectURL(file),
        cover: generatedCover(base),
        duration: 0,
        quality: (file.name.split('.').pop() || 'file').toUpperCase(),
        gradient: 'linear-gradient(115deg, rgba(42,45,80,.95), rgba(25,29,42,.95) 55%, rgba(35,58,58,.95))',
        local: true,
      };
      state.tracks.push(t);
      added++;
      const probe = new Audio();
      probe.preload = 'metadata';
      probe.src = t.src;
      probe.onloadedmetadata = () => {
        if (isFinite(probe.duration)) {
          t.duration = probe.duration;
          audioDurationCache[t.id] = probe.duration;
          renderTracks();
          renderQueue();
        }
      };
    });
    state.view = 'all';
    state.query = '';
    $('#searchInput').value = '';
    renderAll();
    toast(`Добавлено треков: ${added}`);
  }

  /* ---------- visualizer ---------- */
  let audioCtx, analyser, dataArray;
  function initAudioGraph() {
    if (audioCtx) return;
    try {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioCtx.createMediaElementSource(audio);
      analyser = audioCtx.createAnalyser();
      analyser.fftSize = 128;
      analyser.smoothingTimeConstant = 0.82;
      dataArray = new Uint8Array(analyser.frequencyBinCount);
      source.connect(analyser);
      analyser.connect(audioCtx.destination);
    } catch (e) { analyser = null; }
  }

  const canvas = $('#visualizer');
  const cctx = canvas.getContext('2d');
  function drawVisualizer() {
    const w = canvas.width, h = canvas.height;
    cctx.clearRect(0, 0, w, h);
    const bars = 56;
    const gap = 3;
    const bw = (w - gap * (bars - 1)) / bars;
    const grad = cctx.createLinearGradient(0, 0, w, 0);
    grad.addColorStop(0, '#9b8cff');
    grad.addColorStop(0.55, '#8f9dff');
    grad.addColorStop(1, '#64ddc0');
    cctx.fillStyle = grad;
    if (analyser && state.playing) analyser.getByteFrequencyData(dataArray);
    const time = performance.now() / 620;
    for (let i = 0; i < bars; i++) {
      let v;
      if (analyser && state.playing) {
        const index = Math.floor(Math.pow(i / bars, 1.55) * (dataArray.length * 0.78));
        v = Math.min(1, (dataArray[index] || 0) / 210);
      } else {
        v = 0.06 + 0.045 * (1 + Math.sin(time + i * 0.42)) * (1 - i / bars * 0.5);
      }
      const bh = Math.max(4, v * h * 0.94);
      cctx.globalAlpha = state.playing ? 0.95 : 0.35;
      cctx.beginPath();
      cctx.roundRect(i * (bw + gap), h - bh, bw, bh, Math.min(bw / 2, 4));
      cctx.fill();
    }
    cctx.globalAlpha = 1;
    requestAnimationFrame(drawVisualizer);
  }

  /* ---------- context menu ---------- */
  const menu = document.createElement('div');
  menu.className = 'context-menu';
  document.body.appendChild(menu);
  let menuTargetId = null;
  function showMenu(x, y, id) {
    menuTargetId = id;
    const t = trackById(id);
    menu.innerHTML = `
      <div class="menu-title">${escapeHtml(t.title)}</div>
      <button data-act="play">Воспроизвести сейчас</button>
      <button data-act="like">${state.favorites.has(id) ? 'Убрать из любимого' : 'Добавить в любимое'}</button>
      <div class="menu-sep"></div>
      <div class="menu-title small">Добавить в плейлист</div>
      ${state.playlists.map((p) => `<button data-act="pl" data-pl="${p.id}"><span class="playlist-dot" style="background:${p.color}"></span>${escapeHtml(p.name)}</button>`).join('') || '<div class="menu-title small">Нет плейлистов</div>'}
    `;
    menu.style.left = Math.min(x, innerWidth - 230) + 'px';
    menu.style.top = Math.min(y, innerHeight - 290) + 'px';
    menu.classList.add('show');
  }
  const hideMenu = () => menu.classList.remove('show');
  menu.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-act]');
    if (!btn) return;
    const id = menuTargetId;
    if (btn.dataset.act === 'play') playTrack(id, visibleTracks());
    if (btn.dataset.act === 'like') toggleLike(id);
    if (btn.dataset.act === 'pl') {
      const pl = state.playlists.find((p) => p.id === btn.dataset.pl);
      if (pl && !pl.ids.includes(id)) {
        pl.ids.push(id);
        saveStorage();
        renderPlaylistNav();
        toast(`Добавлено в «${pl.name}»`);
      } else toast('Трек уже есть в плейлисте');
    }
    hideMenu();
  });
  document.addEventListener('click', (e) => { if (!menu.contains(e.target)) hideMenu(); });

  /* ---------- events ---------- */
  document.querySelectorAll('.nav-item[data-view]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.view = btn.dataset.view;
      document.querySelectorAll('.nav-item[data-view]').forEach((b) => b.classList.toggle('active', b === btn));
      document.querySelectorAll('[data-playlist]').forEach((b) => b.classList.remove('active'));
      renderTracks();
    });
  });

  $('#searchInput').addEventListener('input', (e) => { state.query = e.target.value.trim(); renderTracks(); });
  $('#btnAddMusic').addEventListener('click', () => $('#fileInput').click());
  $('#fileInput').addEventListener('change', (e) => { addFiles(e.target.files); e.target.value = ''; });
  $('#btnAddPlaylist').addEventListener('click', () => {
    const n = state.playlists.filter((p) => p.name.startsWith('Новый плейлист')).length + 1;
    const pl = { id: 'p' + Date.now(), name: `Новый плейлист ${n}`, color: '#f2a86b', ids: [] };
    state.playlists.push(pl);
    state.view = `playlist:${pl.id}`;
    saveStorage();
    renderAll();
    toast('Плейлист создан — добавьте в него треки через ПКМ');
  });

  $('#btnPlay').addEventListener('click', togglePlay);
  $('#heroPlay').addEventListener('click', togglePlay);
  $('#btnNext').addEventListener('click', () => nextTrack(false));
  $('#btnPrev').addEventListener('click', prevTrack);
  $('#btnShuffle').addEventListener('click', () => {
    state.shuffle = !state.shuffle;
    toast(state.shuffle ? 'Перемешивание включено' : 'Перемешивание выключено');
    renderPlayState();
  });
  $('#btnRepeat').addEventListener('click', () => {
    state.repeat = (state.repeat + 1) % 3;
    toast(['Повтор выключен', 'Повтор списка', 'Повтор одного трека'][state.repeat]);
    renderPlayState();
  });
  ['#heroHeart', '#playerHeart'].forEach((s) => $(s).addEventListener('click', () => toggleLike(state.currentId)));
  $('#btnPlayAll').addEventListener('click', () => {
    const list = visibleTracks();
    if (list.length) { playTrack(list[0].id, list); toast('Играет вся подборка'); }
  });
  $('#btnShuffleAll').addEventListener('click', () => {
    const list = visibleTracks();
    if (!list.length) return;
    state.shuffle = true;
    const shuffled = list.slice().sort(() => Math.random() - 0.5);
    playTrack(shuffled[0].id, shuffled);
    renderPlayState();
    toast('Перемешанная подборка');
  });

  $('#seekBar').addEventListener('input', (e) => {
    if (!isFinite(audio.duration)) return;
    audio.currentTime = (e.target.value / 1000) * audio.duration;
    e.target.style.setProperty('--pct', e.target.value / 10 + '%');
    $('#timeCurrent').textContent = fmt(audio.currentTime);
  });
  $('#volumeBar').addEventListener('input', (e) => {
    state.volume = Number(e.target.value);
    state.muted = false;
    audio.volume = state.volume / 100;
    e.target.style.setProperty('--pct', state.volume + '%');
    $('#volumeValue').textContent = state.volume;
    document.body.classList.remove('muted');
  });
  $('#btnMute').addEventListener('click', () => {
    state.muted = !state.muted;
    audio.muted = state.muted;
    document.body.classList.toggle('muted', state.muted);
    toast(state.muted ? 'Звук выключен' : 'Звук включён');
  });

  $('#btnQueue').addEventListener('click', () => {
    $('#app').classList.toggle('queue-open');
    $('#btnQueue').classList.toggle('on', $('#app').classList.contains('queue-open'));
  });
  $('#btnCloseQueue').addEventListener('click', () => {
    $('#app').classList.remove('queue-open');
    $('#btnQueue').classList.remove('on');
  });

  const desktop = !!window.desktopControls?.available;
  if (desktop) document.body.classList.add('desktop');
  $('#btnMaximize').addEventListener('click', () => {
    if (desktop) window.desktopControls.toggleMaximize();
    else if (document.fullscreenElement) document.exitFullscreen();
    else document.documentElement.requestFullscreen?.().catch(() => toast('Полноэкранный режим недоступен'));
  });
  $('#btnMinimize').addEventListener('click', () => {
    if (desktop) window.desktopControls.minimize();
    else toast('Сворачивание окна доступно в десктопной сборке');
  });
  $('#btnClose').addEventListener('click', () => {
    if (desktop) window.desktopControls.close();
    else toast('Это прототип — окно остаётся открытым');
  });

  $('#trackList').addEventListener('click', (e) => {
    const like = e.target.closest('[data-like]');
    if (like) { e.stopPropagation(); toggleLike(like.dataset.like); return; }
    const row = e.target.closest('.track-row');
    if (row) playTrack(row.dataset.id, visibleTracks());
  });
  $('#trackList').addEventListener('contextmenu', (e) => {
    const row = e.target.closest('.track-row');
    if (!row) return;
    e.preventDefault();
    showMenu(e.clientX, e.clientY, row.dataset.id);
  });

  audio.addEventListener('play', () => {
    initAudioGraph();
    audioCtx?.resume?.();
    state.playing = true;
    renderPlayState();
    renderTracks();
  });
  audio.addEventListener('pause', () => {
    state.playing = false;
    renderPlayState();
    renderTracks();
  });
  audio.addEventListener('ended', () => nextTrack(true));
  audio.addEventListener('loadedmetadata', () => {
    const dur = audio.duration;
    if (isFinite(dur) && current()) {
      current().duration = dur;
      audioDurationCache[current().id] = dur;
    }
    $('#timeTotal').textContent = fmt(dur);
    renderTracks();
    renderQueue();
  });
  audio.addEventListener('timeupdate', () => {
    const pct = audio.duration ? (audio.currentTime / audio.duration) * 1000 : 0;
    $('#seekBar').value = pct;
    $('#seekBar').style.setProperty('--pct', pct / 10 + '%');
    $('#timeCurrent').textContent = fmt(audio.currentTime);
  });
  audio.addEventListener('error', () => {
    if (audio.src) toast('Файл не удалось загрузить');
  });

  // Drag & drop audio files
  let dragDepth = 0;
  window.addEventListener('dragenter', (e) => { if (e.dataTransfer?.types.includes('Files')) { dragDepth++; document.body.classList.add('dragging'); } });
  window.addEventListener('dragover', (e) => { if (e.dataTransfer?.types.includes('Files')) e.preventDefault(); });
  window.addEventListener('dragleave', () => { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) document.body.classList.remove('dragging'); });
  window.addEventListener('drop', (e) => {
    e.preventDefault();
    dragDepth = 0;
    document.body.classList.remove('dragging');
    if (e.dataTransfer.files.length) addFiles(e.dataTransfer.files);
  });

  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    const typing = ['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName);
    if (e.key === 'Escape') { hideMenu(); if (typing) document.activeElement.blur(); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); $('#searchInput').focus(); return; }
    if (typing) return;
    switch (e.key.toLowerCase()) {
      case ' ': e.preventDefault(); togglePlay(); break;
      case 'arrowright': audio.currentTime = Math.min(audio.duration || 0, audio.currentTime + 5); break;
      case 'arrowleft': audio.currentTime = Math.max(0, audio.currentTime - 5); break;
      case 'arrowup': { const v = Math.min(100, state.volume + 5); $('#volumeBar').value = v; $('#volumeBar').dispatchEvent(new Event('input')); break; }
      case 'arrowdown': { const v = Math.max(0, state.volume - 5); $('#volumeBar').value = v; $('#volumeBar').dispatchEvent(new Event('input')); break; }
      case 'n': nextTrack(false); break;
      case 'p': prevTrack(); break;
      case 'm': $('#btnMute').click(); break;
      case 'f': toggleLike(state.currentId); break;
      case 'q': $('#btnQueue').click(); break;
      case '/': e.preventDefault(); $('#searchInput').focus(); break;
    }
  });

  /* ---------- init ---------- */
  loadStorage();
  const hour = new Date().getHours();
  $('#greeting').textContent = hour < 5 ? 'Доброй ночи' : hour < 12 ? 'Доброе утро' : hour < 18 ? 'Добрый день' : 'Добрый вечер';
  audio.volume = state.volume / 100;
  audio.src = current().src;
  audio.load();
  renderAll();
  requestAnimationFrame(drawVisualizer);
})();
